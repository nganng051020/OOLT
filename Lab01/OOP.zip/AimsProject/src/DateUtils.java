import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.Arrays;

public class DateUtils {
	public static void compareTwoDates(String date1, String date2) throws ParseException{
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		Date dateA = formatter.parse(date1);
        Date dateB = formatter.parse(date2);
        
		System.out.println("date1: " + formatter.format(dateA));
		System.out.println("date2: " + formatter.format(dateB));
		
		if(date1.compareTo(date2) > 0) {
			System.out.println(date1 + "before " + date2);
		}
		else if (date1.compareTo(date2) < 0) {
			System.out.println(date1 + "after " + date2);
		}
		else
			System.out.println(date1 + " " + date2);
		
	}
	
	public static void sortingNumberOfDates() throws ParseException{
		Scanner input = new Scanner(System.in);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		System.out.println("Enter size of array: ");
		int size = input.nextInt();
		String strDate[] = new String[size];
		Date date[] = new Date[size];
		
		for(int i = 0; i < size; i++) {
			System.out.printf("strDate[%d]: ", i);
			strDate[i] = input.nextLine();
			date[i] = formatter.parse(strDate[i]);
		}
		Arrays.sort(date);
		System.out.println("********************************RESULT SORTING A NUMBER OF DATES**********************************");
		for(Date test : date) {
			System.out.println(formatter.format(test));
		}
		System.out.println("**************************************************************************************************");
	}
	
	public static void main(String[] args) {
		String date1, date2;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter date1: ");
		date1 = input.nextLine();
		System.out.println("Enter date2: ");
		date2 = input.nextLine();
		//compareTwoDates(date1, date2);
		sortingNumberOfDates();
	}
}
